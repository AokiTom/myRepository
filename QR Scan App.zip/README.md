# MonacaFormApp

### 概要

- 不具合がある場合、issue等から報告してほしい、という文章
- 作成日：2018/02（更新日：2021/01）
- 問い合わせフォーム をイメージしたサンプルアプリを通して、クラウドデータベースへの保存と検索の方法を学んでいく内容

### 動作確認環境/利用SDKバージョン　

- Javascript SDKは組み込まれていません
- Monaca のCordova 9で動作確認しました

### 手順

資料はこちら▼<br>
https://NIFCLOUD-mbaas.github.io/MonacaFormApp/
